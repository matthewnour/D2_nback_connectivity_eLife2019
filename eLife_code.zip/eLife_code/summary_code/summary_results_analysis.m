%% 
clear all

% path to code
addpath('.../eLife_code/summary_code');

% path to summary data
cd('.../eLife_data/summary_data'); 

% subject-level sumamry functional-conenctivity data and PET BPND data
load summary_data.mat % see 'summary_data_readMe.txt'



%% Data for paper figures

% Fig 3a. Mean connectivity change per network edge by WM load (code to
% construct this can be found in the supplementary_code folder)
figure; 
beta = [mean(connChange.DMN,3) mean(connChange.DMNTPN,3);
        mean(connChange.DMNTPN,3)' mean(connChange.TPN,3)];

blue_red=makeColorMap([0 0 1], [1 1 1], [1 0 0], 80);
heatmap_bluered(mean(beta,3), blue_red, [-.1 .1], 'Modulation of functional connectivity by working memory');
set(gca,'XTick', [20 65],'XTickLabel',{'DMN', 'TPN'});
set(gca,'YTick', [20 65],'YTickLabel',{'DMN', 'TPN'});
colorbar; 


% Fig 3b. 
figure;
subplot(1,2,1);

byLoad.DMN = [squeeze(mean(mean(connBlock.back0.DMN))), squeeze(mean(mean(connBlock.back1.DMN))), squeeze(mean(mean(connBlock.back2.DMN)))];
byLoad.TPN = [squeeze(mean(mean(connBlock.back0.TPN))), squeeze(mean(mean(connBlock.back1.TPN))), squeeze(mean(mean(connBlock.back2.TPN)))];
byLoad.DMNTPN = [squeeze(mean(mean(connBlock.back0.DMNTPN))), squeeze(mean(mean(connBlock.back1.DMNTPN))), squeeze(mean(mean(connBlock.back2.DMNTPN)))];

mn = [mean(byLoad.DMN); mean(byLoad.TPN); mean(byLoad.DMNTPN)];
sem = [std(byLoad.DMN)/sqrt(length(byLoad.DMN)); std(byLoad.TPN)/sqrt(length(byLoad.TPN)); std(byLoad.DMNTPN)/sqrt(length(byLoad.DMNTPN))];

for n = 1:size(sem,1);
    errorbar([1 2 3], mn(n,:), sem(n,:)); 
    hold on
end
hold off

legend('DMN', 'TMN', 'DMN-TPN');
xlabel('WM load'); xlim([0 4])
ylabel('Mean Functional Connectivity'); ylim([0 .5])
set(gca,'XTick', [1 2 3], 'XTickLabel',{'0 back', '1 back', '2 back'})


subplot(1,2,2);
BETA.DMN = squeeze(mean(mean(connChange.DMN)));
BETA.TPN = squeeze(mean(mean(connChange.TPN)));
BETA.DMNTPN = squeeze(mean(mean(connChange.DMNTPN)));

mn = [mean(BETA.DMN); mean(BETA.TPN); mean(BETA.DMNTPN)];
sem = [std(BETA.DMN)/sqrt(length(BETA.DMN)); std(BETA.TPN)/sqrt(length(BETA.TPN)); std(BETA.DMNTPN)/sqrt(length(BETA.DMNTPN))];

for n = 1:size(sem,1);
    errorbar(n, mn(n), sem(n)); 
    hold on
end
hold off

xlabel('Network'); xlim([0 4])
ylabel('Task-induced connectivity change (w1)'); ylim([-0.04 0.04])
set(gca,'XTick', [1 2 3], 'XTickLabel',{'DMN', 'TPN', 'DMN-TPN'})


% Fig 4 a&b
figure;
subplot(1,2,1);
scatter(BPND(subjects_with_PET,2), BETA.DMN(subjects_with_PET,1));
xlabel('D2/3R availability in caudate (BPND)'); xlim([0 2.5])
ylabel('Task-induced connectivity change in DMN (w1)'), ylim([-0.3 0.1])

subplot(1,2,2);
scatter(BETA.DMN(:,1), proportional_pRT(:,1));
xlabel('Task-induced connectivity change in DMN (w1)'), xlim([-0.3 0.1])
ylabel('Working memory robustness (-delta pRT(2.5) )'); ylim([-0.8 0.2])
