function [image] =  heatmap_bluered(input_matrix, color_map, axis_limits, chart_title)
% heatmap_rob(input_matrix, color_map, axis_limits, chart_title)
%custom colormap can be generated with makeColorMap
%e.g. heatmap_rob(W_mu,blue_red, [-0.8 0.8], 'Mean Unexposed')
%figure;
imagesc(input_matrix);
colormap(color_map);
caxis(axis_limits);
colorbar;
title(chart_title);
end