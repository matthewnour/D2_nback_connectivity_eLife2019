# Mediation analysis
# Testing the hypothesis that BPND exterts an influence on nback performance, mediated through the influence of BPND on task-induced connectivity change within the DMN

# Data restricted to the N=48 participants who had PET and MRI 
# Uses the mediation package of Tingley et al 

# Matthew M Nour, London, July 2019

install.packages("mediation")
library("mediation")

rm(list = ls())
setwd('.../mediation_data/') # path to "mediation_data_eLife.RData"
load("mediation_data_eLife.RData")

# initialize vectors 
  ACME <- vector(mode = "numeric", 1)
  ACMElowerBound <- ACME
  ACMEupperBound <- ACME
  p <- ACME

# Deine the variables (see mediationReadMe.txt)
  Perf  <- neg_pRT_prop_2.5         # behavioural measure (outcome) (e.g. neg_pRT_prop_2.5)
  fMRI  <- fcDMN                    # fMRI measure (mediator) (e.g. fcDMN)
  DA    <- caudBPND                 # PET measure (e.g. caudBPND)
  
# run the mediation analysis  
  med.fit <- lm( fMRI ~ DA)
  out.fit <- lm( Perf ~ fMRI + DA)
  med.out <- mediate(med.fit, out.fit, boot = TRUE, treat = "DA", mediator = "fMRI", sims = 10000, boot.ci.type = "bca")
  
# Assign the outputs
  ACME <- med.out$d0
  ACMElowerBound <- med.out$d0.ci[1]
  ACMEupperBound <- med.out$d0.ci[2]
  p <- med.out$d0.p
  
  summary(med.out)
