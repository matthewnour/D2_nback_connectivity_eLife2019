function [finalPartition iterations communityAssignment] = consensus_clustering_louvain(inputMatrix, numberPartitions, consensusMatrixThreshold, LouvainMethod, gamma);
% Function to implement consensus clustering as per Lancichinetti & Forunato et al 2012 using the Louvain algorithm as implemented by BCT
%
% Inputs:
%   inputMatrix                 symmetrical weighted undirected adjacency matrix to be partiitioned
%   numberIterations            number of times the algorithm is run to  generate the consensus matrix on each run
%   consensusMatrixThreshold    threshold below which consensus matrix  entries are set to zero, (0 1]
%   LouvainMethod               string of Louvain method: 'Modularity' (if no negative weights in the inputMatrix, or 'negative_sym' / 'negative_asym' if negative weights)
%   gamma                       resolution parameter of Louvain algorithm
% 
% Outputs:
%   finalPartition              1 if two nodes in the same community, 0 if in different communities
%   iterations                  how many iterations to reach consensus
%   communityAssignment         nodes within each community (indices) 
%
%
% Matthew Nour, London, May 2018


D = zeros(size(inputMatrix,1), size(inputMatrix,2), numberPartitions);  %consensus matrix
consensus = 0;
iterations= 0;


while ~ consensus;
    
% generate consensus matrix
for partition = 1:numberPartitions;
    
   
    [community_allocation, Q] = community_louvain(inputMatrix, gamma, [], LouvainMethod); 

  
  for row = 1:size(D,1);
      for col = 1:size(D,2);
          D(row, col, partition) = community_allocation(row) == community_allocation(col);
      end
  end
  
end % end generation of partitions on this run



D = mean(D,3);  
iterations = iterations + 1; 

        if length(unique(D))<3;  % only true if all the parition matrices identical (so that their mean is either 0 or 1);

            consensus = 1;
            
            finalPartition = D;
            finamModularity = Q;

            for community = 1:length(unique(community_allocation));
                   communityAssignment{community} = find((community_allocation)==community);
            end


        else

            D(find(D<consensusMatrixThreshold))=0;
            inputMatrix = D;


        end  % end check if final partition reached

        
end    %end while loop (keeps going until consesnus reached

end    % end function

