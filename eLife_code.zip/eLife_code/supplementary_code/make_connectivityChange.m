% create connChange matrix of connectivity change values (w1 regression coefficient)
% per participant, per network connection. 
%
% Matthew Nour, London, July 2019

cd('/Volumes/NOUR KCL NaN backup/kcl141280_fMRI_nb/eLife_data');
load summary_data.mat connBlock

% Select whether working with DMN, TPN or DMNTPN edges (e.g. here we specifiy DMN edges)
back0 = connBlock.back0.DMN;
back1 = connBlock.back1.DMN;
back2 = connBlock.back2.DMN;

X = [0 1 2]';    % independent variable 

for subj = 1:size(back0,3)
    
    disp(['Subject ' num2str(subj) ' of ' num2str(size(back0,3)) ' started'])
    
    for j = 1:size(back0,1)
        
        for k = 1:size(back0,2)
   
        y = [back0(j,k, subj) back1(j,k, subj) back2(j,k, subj)]';
        
        [B DEV STATS]= glmfit(X,y);
        
        beta(j,k, subj) = B(2);

        end
        
    end
    
    disp(['Subject ' num2str(subj) ' of ' num2str(size(back0,3)) ' done'])
    
end

