function similarity = nodeDice(nodeSet1, nodeSet2)
% nodeDice calculates the Dice similarity coefficient between two sets of logical / {0,1} vecotrs (nodeSet1 and nodeSet2)
% where '1' indicates that the element of the vector is present in nodeSet1/2, and 0 indicates its absence.
% This function assumes that the elements of nodeSet1 and nodeSet2 are in the same order, and uses the intersection of the sets to calculate the Dice coefficient
%
% Matthew Nour, London, 2018 

[~, IA, ~] = intersect(find(nodeSet1),find(nodeSet2));

similarity = 2*( length(IA) ) / (  sum(nodeSet1(:)) + sum(nodeSet2(:)) );

end