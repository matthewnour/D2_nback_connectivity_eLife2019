%Use the functional connectivity data during 0back condition to particion
%the nodes of the Gordon DMN, DAn and FPN into communities, using the
%Louvain algorithm. 
%
% Matthew Nour, London, July 2019

clear all 

% paths
addpath '.../BCT/2017_01_15_BCT' % path to brain connectivity toolbox
addpath ' ... /eLife_code/supplementary_code'

% load in the single-subject 0-back connectivity matrices, restricted to
% the 97 nodes of the DMN, DAN and FPN from the Gordon atlas.
    % nodes 1:41 correspond to Gordon DMN
    % nodes 42:97 correspond to Gordon DAN&FPN
    % see 'ROIdefinitions.xlsx' for more information 
cd('.../eLife_data/supplementary_data/') %path to back0 data
load back0_connectome_Louvain_algorithm

% Community Detection Parameters
gamma = 1; % resolution parameter of the Louvain algorithm
repeats = 1000; % iterations of the consensus procedure
tau = 0.5; % threshold of the consensus matrix filtering step



%% Conduct community detection using the Louvain algorithm (setting negative weights to 0)

% community detection on each participant individually 
for n = 1:size(back0_raw,3); 
    
    inputMatrix = back0_raw(:,:,n);
    inputMatrix(inputMatrix<0) = 0;
    
    [partitionMatrix(:,:,n), iterations(n), indiv_nodeAllocations{n}] = consensus_clustering_louvain(inputMatrix, repeats, tau, 'modularity', gamma);
    
    
end


% Two large communities detected. 
% Calculate the DICE overlap between community node membership and the a priori Gordon node assignments

    % overlap between community 1 and Gordon DMN
    comm1 = zeros(size(back0_raw,1),1);
    comm1(nodeAllocations{1},1) = 1;
    comm1 = logical(comm1);
    
    comm2 = zeros(size(back0_raw,1),1);
    comm2(nodeAllocations{2},1) = 1;
    comm2 = logical(comm2);
     
    DMN = logical([ones(41,1); zeros(56,1)]);
    TPN = ~(DMN);
    
    disp('')
    disp('Empirical Community 1:')
    disp(['Number of nodes: ' num2str(sum(comm1))])
    disp(['DICE overlap with Gordon DMN: ' num2str(nodeDice(comm1, DMN))]);
    disp(['DICE overlap with Gordon DAN&FPN: ' num2str(nodeDice(comm1, TPN))]);
    disp('')
    disp('Empirical Community 2:')
    disp(['Number of nodes: ' num2str(sum(comm2))])
    disp(['DICE overlap with Gordon DMN: ' num2str(nodeDice(comm2, DMN))]);
    disp(['DICE overlap with Gordon DAN&FPN: ' num2str(nodeDice(comm2, TPN))]);
    
