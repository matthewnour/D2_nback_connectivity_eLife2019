Guide to "mediation_data_N48_eLife.RData"

Performance variables
 - neg_pRT_prop_2.5	negative delta pRT (penalisation ratio = 2.5)
 - neg_pRT_prop_3.0	negative delta pRT (penalisation ratio = 3.0)
 - neg_pRT_prop_3.5	negative delta pRT (penalisation ratio = 3.5)
 - neg_pRT_prop_4.0	negative delta pRT (penalisation ratio = 4.0)


Task-induced connectivity change variables
 - fcDMN 				mean task-induced connectivity change in DMN (w1)
 - fcTPN 				mean task-induced connectivity change in TPN (w1)
 - fcDMNTPN 				mean task-induced connectivity change in DMN-TPN (w1)


BPND
 - caudBPND 				D2/3R availability in bilateral caudate
 - accumbesBPND 			D2/3R availability in bilateral accumbent
 - wholeStriatumBPND 			D2/3R availability in bilateral whole striatum (caudate + accumbent + putamen)
