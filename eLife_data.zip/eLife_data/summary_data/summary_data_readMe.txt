summary_data.mat explanation

Functional connectivity data structures (size = [numROI * numROI * numSubj]):

    connBlock           undirected functional connectivity values (z-transformed r-values) for each task  condition (0back, 1back and 2back) and averaged over whole task (wholeTask).
    connChange          regression coefficient (w1) describing connectivity change as a function of working memory load for each network edge and each subject. See 'make_connectivityChange.m' for how this was constructed. 


Subject variables (size = numSubj * n])
	Age                 Age in years
    	Male                Male = 1, Female = 0
    	proportional_rPT    -deltapRT (behavioural emasure as described in text), using penalization ratios of [2.5, 3.0, 3.5, 4.0]
    	BPND                D2/3R availability (PHNO non-displaceable binding potential) for [bilateral_whole_striatum, bilateral_caudate,  bilateral_accumbens and bilateral_SNVTA] (as described in text)

    	subjects_with_PET     indices of the subjects who haev PET data ( = find(~isnan(BPND(:,1))) )

Note on fc connectors ROI definition
Default mode network (DMN) and task positive network (TPN) node sets are defined using consensus clustering approach on the set of 97 nodes of the DMN, DAN and FPN from the Gordon parcellation, as described in text. For further information see the 'empirical_clustering.m' script and the ROIdefinitions.xlsx file. 
    